-- 3 Musketeers
module Average3 where
average3 :: (Double, Double, Double) -> Double
average3 (a, b, c) = (a + b + c)/3
